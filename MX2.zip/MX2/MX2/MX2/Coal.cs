﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MX2
{
    class Coal:Tail
    {
        public Coal()
        {
            Name = "Coal";
            Coal = 1;
            Iron = 0;
            Concreat = 0;
            Water = 0;
        }
    }
}
