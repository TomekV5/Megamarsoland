﻿
namespace MX2
{
    partial class mapOfMars
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            confirm = new System.Windows.Forms.Button();
            next = new System.Windows.Forms.Button();
            rece = new System.Windows.Forms.Button();
            c = new System.Windows.Forms.TextBox();
            l = new System.Windows.Forms.TextBox();
            label1 = new System.Windows.Forms.Label();
            label2 = new System.Windows.Forms.Label();
            numbers = new System.Windows.Forms.Label();
            table = new System.Windows.Forms.Label();
            tpln = new System.Windows.Forms.Label();
            ironc = new System.Windows.Forms.Label();
            coalc = new System.Windows.Forms.Label();
            concreatc = new System.Windows.Forms.Label();
            waterc = new System.Windows.Forms.Label();
            label3 = new System.Windows.Forms.Label();
            label4 = new System.Windows.Forms.Label();
            label5 = new System.Windows.Forms.Label();
            label6 = new System.Windows.Forms.Label();
            label7 = new System.Windows.Forms.Label();
            label8 = new System.Windows.Forms.Label();
            SuspendLayout();
            // 
            // confirm
            // 
            confirm.BackColor = System.Drawing.Color.DeepSkyBlue;
            confirm.Font = new System.Drawing.Font("Consolas", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            confirm.Location = new System.Drawing.Point(904, 193);
            confirm.Name = "confirm";
            confirm.Size = new System.Drawing.Size(116, 51);
            confirm.TabIndex = 5;
            confirm.Text = "Confirm";
            confirm.UseVisualStyleBackColor = false;
            confirm.Click += confirm_Click;
            // 
            // next
            // 
            next.BackColor = System.Drawing.Color.DeepSkyBlue;
            next.Font = new System.Drawing.Font("Consolas", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            next.Location = new System.Drawing.Point(979, 128);
            next.Name = "next";
            next.Size = new System.Drawing.Size(103, 59);
            next.TabIndex = 3;
            next.Text = "Show";
            next.UseVisualStyleBackColor = false;
            next.Click += next_Click;
            // 
            // rece
            // 
            rece.BackColor = System.Drawing.Color.DeepSkyBlue;
            rece.Font = new System.Drawing.Font("Consolas", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            rece.Location = new System.Drawing.Point(851, 128);
            rece.Name = "rece";
            rece.Size = new System.Drawing.Size(103, 59);
            rece.TabIndex = 4;
            rece.Text = "Reset";
            rece.UseVisualStyleBackColor = false;
            rece.Click += rece_Click;
            // 
            // c
            // 
            c.Font = new System.Drawing.Font("Consolas", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            c.Location = new System.Drawing.Point(979, 50);
            c.Name = "c";
            c.Size = new System.Drawing.Size(100, 36);
            c.TabIndex = 1;
            // 
            // l
            // 
            l.Font = new System.Drawing.Font("Consolas", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            l.Location = new System.Drawing.Point(979, 87);
            l.Name = "l";
            l.Size = new System.Drawing.Size(100, 36);
            l.TabIndex = 2;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new System.Drawing.Font("Consolas", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            label1.Location = new System.Drawing.Point(792, 52);
            label1.Name = "label1";
            label1.Size = new System.Drawing.Size(181, 28);
            label1.TabIndex = 5;
            label1.Text = "Write column:";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new System.Drawing.Font("Consolas", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            label2.Location = new System.Drawing.Point(792, 89);
            label2.Name = "label2";
            label2.Size = new System.Drawing.Size(155, 28);
            label2.TabIndex = 6;
            label2.Text = "Write rows:";
            // 
            // numbers
            // 
            numbers.AutoSize = true;
            numbers.Font = new System.Drawing.Font("Consolas", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            numbers.Location = new System.Drawing.Point(56, 72);
            numbers.Name = "numbers";
            numbers.Size = new System.Drawing.Size(70, 22);
            numbers.TabIndex = 7;
            numbers.Text = "label3";
            // 
            // table
            // 
            table.AutoSize = true;
            table.Font = new System.Drawing.Font("Consolas", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            table.Location = new System.Drawing.Point(93, 50);
            table.Name = "table";
            table.Size = new System.Drawing.Size(70, 22);
            table.TabIndex = 8;
            table.Text = "label3";
            // 
            // tpln
            // 
            tpln.AutoSize = true;
            tpln.Font = new System.Drawing.Font("Consolas", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            tpln.Location = new System.Drawing.Point(904, 314);
            tpln.Name = "tpln";
            tpln.Size = new System.Drawing.Size(25, 28);
            tpln.TabIndex = 9;
            tpln.Text = "0";
            // 
            // ironc
            // 
            ironc.AutoSize = true;
            ironc.Font = new System.Drawing.Font("Consolas", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            ironc.Location = new System.Drawing.Point(904, 347);
            ironc.Name = "ironc";
            ironc.Size = new System.Drawing.Size(25, 28);
            ironc.TabIndex = 10;
            ironc.Text = "0";
            // 
            // coalc
            // 
            coalc.AutoSize = true;
            coalc.Font = new System.Drawing.Font("Consolas", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            coalc.Location = new System.Drawing.Point(904, 381);
            coalc.Name = "coalc";
            coalc.Size = new System.Drawing.Size(25, 28);
            coalc.TabIndex = 11;
            coalc.Text = "0";
            // 
            // concreatc
            // 
            concreatc.AutoSize = true;
            concreatc.Font = new System.Drawing.Font("Consolas", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            concreatc.Location = new System.Drawing.Point(904, 415);
            concreatc.Name = "concreatc";
            concreatc.Size = new System.Drawing.Size(25, 28);
            concreatc.TabIndex = 12;
            concreatc.Text = "0";
            // 
            // waterc
            // 
            waterc.AutoSize = true;
            waterc.Font = new System.Drawing.Font("Consolas", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            waterc.Location = new System.Drawing.Point(904, 450);
            waterc.Name = "waterc";
            waterc.Size = new System.Drawing.Size(25, 28);
            waterc.TabIndex = 13;
            waterc.Text = "0";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new System.Drawing.Font("Consolas", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            label3.Location = new System.Drawing.Point(782, 314);
            label3.Name = "label3";
            label3.Size = new System.Drawing.Size(77, 28);
            label3.TabIndex = 14;
            label3.Text = "Type:";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new System.Drawing.Font("Consolas", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            label4.Location = new System.Drawing.Point(782, 347);
            label4.Name = "label4";
            label4.Size = new System.Drawing.Size(77, 28);
            label4.TabIndex = 15;
            label4.Text = "Iron:";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new System.Drawing.Font("Consolas", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            label5.Location = new System.Drawing.Point(782, 381);
            label5.Name = "label5";
            label5.Size = new System.Drawing.Size(77, 28);
            label5.TabIndex = 16;
            label5.Text = "Coal:";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new System.Drawing.Font("Consolas", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            label6.Location = new System.Drawing.Point(782, 415);
            label6.Name = "label6";
            label6.Size = new System.Drawing.Size(129, 28);
            label6.TabIndex = 17;
            label6.Text = "Concreat:";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new System.Drawing.Font("Consolas", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            label7.Location = new System.Drawing.Point(782, 450);
            label7.Name = "label7";
            label7.Size = new System.Drawing.Size(90, 28);
            label7.TabIndex = 18;
            label7.Text = "Water:";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Font = new System.Drawing.Font("Consolas", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            label8.Location = new System.Drawing.Point(782, 270);
            label8.Name = "label8";
            label8.Size = new System.Drawing.Size(129, 28);
            label8.TabIndex = 19;
            label8.Text = "Resorses:";
            // 
            // mapOfMars
            // 
            AutoScaleDimensions = new System.Drawing.SizeF(10F, 22F);
            AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            BackColor = System.Drawing.Color.FromArgb(255, 128, 0);
            ClientSize = new System.Drawing.Size(1143, 660);
            Controls.Add(label8);
            Controls.Add(label7);
            Controls.Add(label6);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(waterc);
            Controls.Add(concreatc);
            Controls.Add(coalc);
            Controls.Add(ironc);
            Controls.Add(tpln);
            Controls.Add(table);
            Controls.Add(numbers);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(l);
            Controls.Add(c);
            Controls.Add(rece);
            Controls.Add(next);
            Controls.Add(confirm);
            Font = new System.Drawing.Font("Consolas", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            Margin = new System.Windows.Forms.Padding(4);
            Name = "mapOfMars";
            Text = "Form1";
            Load += mapOfMars_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private System.Windows.Forms.Button confirm;
        private System.Windows.Forms.Button next;
        private System.Windows.Forms.Button rece;
        private System.Windows.Forms.TextBox c;
        private System.Windows.Forms.TextBox l;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label numbers;
        private System.Windows.Forms.Label table;
        private System.Windows.Forms.Label tpln;
        private System.Windows.Forms.Label ironc;
        private System.Windows.Forms.Label coalc;
        private System.Windows.Forms.Label concreatc;
        private System.Windows.Forms.Label waterc;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
    }
}

