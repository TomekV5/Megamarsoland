﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MX2
{
    class Concreat:Tail
    {
        public Concreat()
        {
            Name = "Con";
            Coal = 0;
            Iron = 0;
            Concreat = 1;
            Water = 0;
        }
    }
}
