﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MX2
{
    class Iron:Tail
    {
        public Iron()
        {
            Name = "I";
            Coal = 0;
            Iron = 1;
            Concreat = 0;
            Water = 1;
        }
    }
}
