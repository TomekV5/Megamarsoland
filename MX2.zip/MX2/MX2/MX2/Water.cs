﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MX2
{
    class Water:Tail
    {
        public Water()
        {
            Name = "W";
            Coal = 0;
            Iron = 0;
            Concreat = 0;
            Water = 1;
        }
    }
}
