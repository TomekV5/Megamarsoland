﻿
namespace MX2
{
    partial class Plotmapcs
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            table = new System.Windows.Forms.Label();
            numbers = new System.Windows.Forms.Label();
            label2 = new System.Windows.Forms.Label();
            label1 = new System.Windows.Forms.Label();
            l = new System.Windows.Forms.TextBox();
            c = new System.Windows.Forms.TextBox();
            rece = new System.Windows.Forms.Button();
            next = new System.Windows.Forms.Button();
            confirm = new System.Windows.Forms.Button();
            ironc = new System.Windows.Forms.Label();
            coalc = new System.Windows.Forms.Label();
            concreatc = new System.Windows.Forms.Label();
            waterc = new System.Windows.Forms.Label();
            moneyt = new System.Windows.Forms.Label();
            label8 = new System.Windows.Forms.Label();
            resorstext = new System.Windows.Forms.Label();
            SuspendLayout();
            // 
            // table
            // 
            table.AutoSize = true;
            table.Location = new System.Drawing.Point(101, 29);
            table.Name = "table";
            table.Size = new System.Drawing.Size(70, 22);
            table.TabIndex = 17;
            table.Text = "label3";
            // 
            // numbers
            // 
            numbers.AutoSize = true;
            numbers.Location = new System.Drawing.Point(64, 51);
            numbers.Name = "numbers";
            numbers.Size = new System.Drawing.Size(70, 22);
            numbers.TabIndex = 16;
            numbers.Text = "label3";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new System.Drawing.Font("Consolas", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            label2.Location = new System.Drawing.Point(777, 66);
            label2.Name = "label2";
            label2.Size = new System.Drawing.Size(155, 28);
            label2.TabIndex = 15;
            label2.Text = "Write rows:";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new System.Drawing.Font("Consolas", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            label1.Location = new System.Drawing.Point(777, 26);
            label1.Name = "label1";
            label1.Size = new System.Drawing.Size(181, 28);
            label1.TabIndex = 14;
            label1.Text = "Write column:";
            // 
            // l
            // 
            l.Font = new System.Drawing.Font("Consolas", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            l.Location = new System.Drawing.Point(965, 63);
            l.Name = "l";
            l.Size = new System.Drawing.Size(100, 36);
            l.TabIndex = 1;
            // 
            // c
            // 
            c.Font = new System.Drawing.Font("Consolas", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            c.Location = new System.Drawing.Point(965, 26);
            c.Name = "c";
            c.Size = new System.Drawing.Size(100, 36);
            c.TabIndex = 0;
            // 
            // rece
            // 
            rece.BackColor = System.Drawing.Color.DeepSkyBlue;
            rece.Font = new System.Drawing.Font("Consolas", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            rece.Location = new System.Drawing.Point(829, 107);
            rece.Name = "rece";
            rece.Size = new System.Drawing.Size(103, 59);
            rece.TabIndex = 3;
            rece.Text = "Reset";
            rece.UseVisualStyleBackColor = false;
            rece.Click += rece_Click;
            // 
            // next
            // 
            next.BackColor = System.Drawing.Color.DeepSkyBlue;
            next.Font = new System.Drawing.Font("Consolas", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            next.Location = new System.Drawing.Point(957, 107);
            next.Name = "next";
            next.Size = new System.Drawing.Size(103, 59);
            next.TabIndex = 2;
            next.Text = "Show";
            next.UseVisualStyleBackColor = false;
            next.Click += next_Click;
            // 
            // confirm
            // 
            confirm.BackColor = System.Drawing.Color.DeepSkyBlue;
            confirm.Font = new System.Drawing.Font("Consolas", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            confirm.Location = new System.Drawing.Point(882, 172);
            confirm.Name = "confirm";
            confirm.Size = new System.Drawing.Size(116, 51);
            confirm.TabIndex = 4;
            confirm.Text = "Confirm";
            confirm.UseVisualStyleBackColor = false;
            confirm.Click += confirm_Click;
            // 
            // ironc
            // 
            ironc.AutoSize = true;
            ironc.Font = new System.Drawing.Font("Consolas", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            ironc.Location = new System.Drawing.Point(829, 306);
            ironc.Name = "ironc";
            ironc.Size = new System.Drawing.Size(90, 28);
            ironc.TabIndex = 29;
            ironc.Text = "label1";
            // 
            // coalc
            // 
            coalc.AutoSize = true;
            coalc.Font = new System.Drawing.Font("Consolas", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            coalc.Location = new System.Drawing.Point(925, 306);
            coalc.Name = "coalc";
            coalc.Size = new System.Drawing.Size(90, 28);
            coalc.TabIndex = 28;
            coalc.Text = "label1";
            // 
            // concreatc
            // 
            concreatc.AutoSize = true;
            concreatc.Font = new System.Drawing.Font("Consolas", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            concreatc.Location = new System.Drawing.Point(829, 371);
            concreatc.Name = "concreatc";
            concreatc.Size = new System.Drawing.Size(90, 28);
            concreatc.TabIndex = 27;
            concreatc.Text = "label1";
            // 
            // waterc
            // 
            waterc.AutoSize = true;
            waterc.Font = new System.Drawing.Font("Consolas", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            waterc.Location = new System.Drawing.Point(925, 371);
            waterc.Name = "waterc";
            waterc.Size = new System.Drawing.Size(90, 28);
            waterc.TabIndex = 26;
            waterc.Text = "label1";
            // 
            // moneyt
            // 
            moneyt.AutoSize = true;
            moneyt.Font = new System.Drawing.Font("Consolas", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            moneyt.Location = new System.Drawing.Point(1015, 334);
            moneyt.Name = "moneyt";
            moneyt.Size = new System.Drawing.Size(90, 28);
            moneyt.TabIndex = 25;
            moneyt.Text = "label1";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Font = new System.Drawing.Font("Consolas", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            label8.Location = new System.Drawing.Point(829, 263);
            label8.Name = "label8";
            label8.Size = new System.Drawing.Size(129, 28);
            label8.TabIndex = 30;
            label8.Text = "Resorses:";
            // 
            // resorstext
            // 
            resorstext.AutoSize = true;
            resorstext.Font = new System.Drawing.Font("Consolas", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            resorstext.Location = new System.Drawing.Point(829, 442);
            resorstext.Name = "resorstext";
            resorstext.Size = new System.Drawing.Size(0, 28);
            resorstext.TabIndex = 31;
            // 
            // Plotmapcs
            // 
            AutoScaleDimensions = new System.Drawing.SizeF(10F, 22F);
            AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            BackColor = System.Drawing.Color.FromArgb(255, 128, 0);
            ClientSize = new System.Drawing.Size(1143, 660);
            Controls.Add(resorstext);
            Controls.Add(label8);
            Controls.Add(ironc);
            Controls.Add(coalc);
            Controls.Add(concreatc);
            Controls.Add(waterc);
            Controls.Add(moneyt);
            Controls.Add(table);
            Controls.Add(numbers);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(l);
            Controls.Add(c);
            Controls.Add(rece);
            Controls.Add(next);
            Controls.Add(confirm);
            Font = new System.Drawing.Font("Consolas", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            Margin = new System.Windows.Forms.Padding(4);
            Name = "Plotmapcs";
            Text = "Plotmapcs";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private System.Windows.Forms.Label table;
        private System.Windows.Forms.Label numbers;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox l;
        private System.Windows.Forms.TextBox c;
        private System.Windows.Forms.Button rece;
        private System.Windows.Forms.Button next;
        private System.Windows.Forms.Button confirm;
        private System.Windows.Forms.Label ironc;
        private System.Windows.Forms.Label coalc;
        private System.Windows.Forms.Label concreatc;
        private System.Windows.Forms.Label waterc;
        private System.Windows.Forms.Label moneyt;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label resorstext;
    }
}