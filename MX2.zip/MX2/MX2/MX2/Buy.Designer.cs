﻿
namespace MX2
{
    partial class Buy
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Buy));
            clear = new System.Windows.Forms.Button();
            sum = new System.Windows.Forms.Button();
            buyyy = new System.Windows.Forms.Button();
            finish = new System.Windows.Forms.Button();
            iron = new System.Windows.Forms.Label();
            coal = new System.Windows.Forms.Label();
            concreat = new System.Windows.Forms.Label();
            water = new System.Windows.Forms.Label();
            numericUpDownIron = new System.Windows.Forms.NumericUpDown();
            numericUpDownCoal = new System.Windows.Forms.NumericUpDown();
            numericUpDownConcreat = new System.Windows.Forms.NumericUpDown();
            numericUpDownWater = new System.Windows.Forms.NumericUpDown();
            ironmoney = new System.Windows.Forms.Label();
            coalmoney = new System.Windows.Forms.Label();
            concreatmoney = new System.Windows.Forms.Label();
            watermoney = new System.Windows.Forms.Label();
            irontotal = new System.Windows.Forms.Label();
            coaltotal = new System.Windows.Forms.Label();
            cocreattotal = new System.Windows.Forms.Label();
            watertotal = new System.Windows.Forms.Label();
            label13 = new System.Windows.Forms.Label();
            total = new System.Windows.Forms.Label();
            yourmoneytext = new System.Windows.Forms.Label();
            totla = new System.Windows.Forms.Label();
            finalmoney = new System.Windows.Forms.Label();
            you = new System.Windows.Forms.Label();
            tooo = new System.Windows.Forms.Label();
            fff = new System.Windows.Forms.Label();
            pictureBox1 = new System.Windows.Forms.PictureBox();
            bt = new System.Windows.Forms.Label();
            ironc = new System.Windows.Forms.Label();
            coalc = new System.Windows.Forms.Label();
            concreatc = new System.Windows.Forms.Label();
            waterc = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)numericUpDownIron).BeginInit();
            ((System.ComponentModel.ISupportInitialize)numericUpDownCoal).BeginInit();
            ((System.ComponentModel.ISupportInitialize)numericUpDownConcreat).BeginInit();
            ((System.ComponentModel.ISupportInitialize)numericUpDownWater).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // clear
            // 
            clear.BackColor = System.Drawing.Color.Red;
            clear.Font = new System.Drawing.Font("Consolas", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            clear.Location = new System.Drawing.Point(12, 515);
            clear.Name = "clear";
            clear.Size = new System.Drawing.Size(122, 47);
            clear.TabIndex = 0;
            clear.Text = "Clear";
            clear.UseVisualStyleBackColor = false;
            clear.Click += clear_Click;
            // 
            // sum
            // 
            sum.BackColor = System.Drawing.Color.Red;
            sum.Font = new System.Drawing.Font("Consolas", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            sum.Location = new System.Drawing.Point(162, 515);
            sum.Name = "sum";
            sum.Size = new System.Drawing.Size(104, 47);
            sum.TabIndex = 1;
            sum.Text = "Sum";
            sum.UseVisualStyleBackColor = false;
            sum.Click += sum_Click;
            // 
            // buyyy
            // 
            buyyy.BackColor = System.Drawing.Color.Red;
            buyyy.Font = new System.Drawing.Font("Consolas", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            buyyy.Location = new System.Drawing.Point(299, 515);
            buyyy.Name = "buyyy";
            buyyy.Size = new System.Drawing.Size(109, 47);
            buyyy.TabIndex = 2;
            buyyy.Text = "Buy";
            buyyy.UseVisualStyleBackColor = false;
            buyyy.Click += buyyy_Click;
            // 
            // finish
            // 
            finish.BackColor = System.Drawing.Color.Red;
            finish.Font = new System.Drawing.Font("Consolas", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            finish.Location = new System.Drawing.Point(717, 515);
            finish.Name = "finish";
            finish.Size = new System.Drawing.Size(113, 48);
            finish.TabIndex = 3;
            finish.Text = "Finish";
            finish.UseVisualStyleBackColor = false;
            finish.Click += finish_Click;
            // 
            // iron
            // 
            iron.AutoSize = true;
            iron.Font = new System.Drawing.Font("Consolas", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            iron.Location = new System.Drawing.Point(12, 94);
            iron.Name = "iron";
            iron.Size = new System.Drawing.Size(74, 32);
            iron.TabIndex = 4;
            iron.Text = "Iron";
            // 
            // coal
            // 
            coal.AutoSize = true;
            coal.Font = new System.Drawing.Font("Consolas", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            coal.Location = new System.Drawing.Point(12, 155);
            coal.Name = "coal";
            coal.Size = new System.Drawing.Size(74, 32);
            coal.TabIndex = 5;
            coal.Text = "Coal";
            // 
            // concreat
            // 
            concreat.AutoSize = true;
            concreat.Font = new System.Drawing.Font("Consolas", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            concreat.Location = new System.Drawing.Point(12, 218);
            concreat.Name = "concreat";
            concreat.Size = new System.Drawing.Size(134, 32);
            concreat.TabIndex = 6;
            concreat.Text = "Concreat";
            // 
            // water
            // 
            water.AutoSize = true;
            water.Font = new System.Drawing.Font("Consolas", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            water.Location = new System.Drawing.Point(12, 278);
            water.Name = "water";
            water.Size = new System.Drawing.Size(89, 32);
            water.TabIndex = 7;
            water.Text = "Water";
            // 
            // numericUpDownIron
            // 
            numericUpDownIron.Location = new System.Drawing.Point(205, 92);
            numericUpDownIron.Name = "numericUpDownIron";
            numericUpDownIron.Size = new System.Drawing.Size(78, 30);
            numericUpDownIron.TabIndex = 8;
            // 
            // numericUpDownCoal
            // 
            numericUpDownCoal.Location = new System.Drawing.Point(205, 153);
            numericUpDownCoal.Name = "numericUpDownCoal";
            numericUpDownCoal.Size = new System.Drawing.Size(78, 30);
            numericUpDownCoal.TabIndex = 9;
            // 
            // numericUpDownConcreat
            // 
            numericUpDownConcreat.Location = new System.Drawing.Point(205, 216);
            numericUpDownConcreat.Name = "numericUpDownConcreat";
            numericUpDownConcreat.Size = new System.Drawing.Size(78, 30);
            numericUpDownConcreat.TabIndex = 10;
            // 
            // numericUpDownWater
            // 
            numericUpDownWater.Location = new System.Drawing.Point(205, 276);
            numericUpDownWater.Name = "numericUpDownWater";
            numericUpDownWater.Size = new System.Drawing.Size(78, 30);
            numericUpDownWater.TabIndex = 11;
            // 
            // ironmoney
            // 
            ironmoney.AutoSize = true;
            ironmoney.Font = new System.Drawing.Font("Consolas", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            ironmoney.Location = new System.Drawing.Point(152, 94);
            ironmoney.Name = "ironmoney";
            ironmoney.Size = new System.Drawing.Size(44, 32);
            ironmoney.TabIndex = 12;
            ironmoney.Text = "20";
            // 
            // coalmoney
            // 
            coalmoney.AutoSize = true;
            coalmoney.Font = new System.Drawing.Font("Consolas", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            coalmoney.Location = new System.Drawing.Point(152, 155);
            coalmoney.Name = "coalmoney";
            coalmoney.Size = new System.Drawing.Size(44, 32);
            coalmoney.TabIndex = 13;
            coalmoney.Text = "15";
            // 
            // concreatmoney
            // 
            concreatmoney.AutoSize = true;
            concreatmoney.Font = new System.Drawing.Font("Consolas", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            concreatmoney.Location = new System.Drawing.Point(152, 224);
            concreatmoney.Name = "concreatmoney";
            concreatmoney.Size = new System.Drawing.Size(44, 32);
            concreatmoney.TabIndex = 14;
            concreatmoney.Text = "10";
            // 
            // watermoney
            // 
            watermoney.AutoSize = true;
            watermoney.Font = new System.Drawing.Font("Consolas", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            watermoney.Location = new System.Drawing.Point(152, 284);
            watermoney.Name = "watermoney";
            watermoney.Size = new System.Drawing.Size(29, 32);
            watermoney.TabIndex = 15;
            watermoney.Text = "5";
            // 
            // irontotal
            // 
            irontotal.AutoSize = true;
            irontotal.Font = new System.Drawing.Font("Consolas", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            irontotal.Location = new System.Drawing.Point(317, 90);
            irontotal.Name = "irontotal";
            irontotal.Size = new System.Drawing.Size(44, 32);
            irontotal.TabIndex = 16;
            irontotal.Text = "0$";
            // 
            // coaltotal
            // 
            coaltotal.AutoSize = true;
            coaltotal.Font = new System.Drawing.Font("Consolas", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            coaltotal.Location = new System.Drawing.Point(317, 147);
            coaltotal.Name = "coaltotal";
            coaltotal.Size = new System.Drawing.Size(44, 32);
            coaltotal.TabIndex = 17;
            coaltotal.Text = "0$";
            // 
            // cocreattotal
            // 
            cocreattotal.AutoSize = true;
            cocreattotal.Font = new System.Drawing.Font("Consolas", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            cocreattotal.Location = new System.Drawing.Point(317, 216);
            cocreattotal.Name = "cocreattotal";
            cocreattotal.Size = new System.Drawing.Size(44, 32);
            cocreattotal.TabIndex = 18;
            cocreattotal.Text = "0$";
            // 
            // watertotal
            // 
            watertotal.AutoSize = true;
            watertotal.Font = new System.Drawing.Font("Consolas", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            watertotal.Location = new System.Drawing.Point(317, 278);
            watertotal.Name = "watertotal";
            watertotal.Size = new System.Drawing.Size(44, 32);
            watertotal.TabIndex = 19;
            watertotal.Text = "0$";
            // 
            // label13
            // 
            label13.AutoSize = true;
            label13.Font = new System.Drawing.Font("Consolas", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            label13.Location = new System.Drawing.Point(117, 338);
            label13.Name = "label13";
            label13.Size = new System.Drawing.Size(194, 32);
            label13.TabIndex = 20;
            label13.Text = "Total money:";
            // 
            // total
            // 
            total.AutoSize = true;
            total.Font = new System.Drawing.Font("Consolas", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            total.Location = new System.Drawing.Point(317, 338);
            total.Name = "total";
            total.Size = new System.Drawing.Size(44, 32);
            total.TabIndex = 21;
            total.Text = "0$";
            // 
            // yourmoneytext
            // 
            yourmoneytext.AutoSize = true;
            yourmoneytext.Font = new System.Drawing.Font("Consolas", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            yourmoneytext.Location = new System.Drawing.Point(205, 386);
            yourmoneytext.Name = "yourmoneytext";
            yourmoneytext.Size = new System.Drawing.Size(164, 32);
            yourmoneytext.TabIndex = 22;
            yourmoneytext.Text = "Your money";
            // 
            // totla
            // 
            totla.AutoSize = true;
            totla.Font = new System.Drawing.Font("Consolas", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            totla.Location = new System.Drawing.Point(376, 386);
            totla.Name = "totla";
            totla.Size = new System.Drawing.Size(209, 32);
            totla.TabIndex = 23;
            totla.Text = "- spend money";
            // 
            // finalmoney
            // 
            finalmoney.AutoSize = true;
            finalmoney.Font = new System.Drawing.Font("Consolas", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            finalmoney.Location = new System.Drawing.Point(591, 386);
            finalmoney.Name = "finalmoney";
            finalmoney.Size = new System.Drawing.Size(239, 32);
            finalmoney.TabIndex = 24;
            finalmoney.Text = "=Remainig money";
            // 
            // you
            // 
            you.AutoSize = true;
            you.Font = new System.Drawing.Font("Consolas", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            you.Location = new System.Drawing.Point(269, 447);
            you.Name = "you";
            you.Size = new System.Drawing.Size(29, 32);
            you.TabIndex = 25;
            you.Text = "0";
            // 
            // tooo
            // 
            tooo.AutoSize = true;
            tooo.Font = new System.Drawing.Font("Consolas", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            tooo.Location = new System.Drawing.Point(466, 447);
            tooo.Name = "tooo";
            tooo.Size = new System.Drawing.Size(29, 32);
            tooo.TabIndex = 26;
            tooo.Text = "0";
            // 
            // fff
            // 
            fff.AutoSize = true;
            fff.Font = new System.Drawing.Font("Consolas", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            fff.Location = new System.Drawing.Point(687, 447);
            fff.Name = "fff";
            fff.Size = new System.Drawing.Size(29, 32);
            fff.TabIndex = 27;
            fff.Text = "0";
            // 
            // pictureBox1
            // 
            pictureBox1.BackgroundImage = (System.Drawing.Image)resources.GetObject("pictureBox1.BackgroundImage");
            pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            pictureBox1.Location = new System.Drawing.Point(466, 130);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new System.Drawing.Size(364, 224);
            pictureBox1.TabIndex = 28;
            pictureBox1.TabStop = false;
            // 
            // bt
            // 
            bt.AutoSize = true;
            bt.Font = new System.Drawing.Font("Cooper Black", 27.75F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point);
            bt.Location = new System.Drawing.Point(358, 20);
            bt.Name = "bt";
            bt.Size = new System.Drawing.Size(118, 42);
            bt.TabIndex = 29;
            bt.Text = "Bank";
            // 
            // ironc
            // 
            ironc.AutoSize = true;
            ironc.Font = new System.Drawing.Font("Consolas", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            ironc.Location = new System.Drawing.Point(457, 75);
            ironc.Name = "ironc";
            ironc.Size = new System.Drawing.Size(104, 32);
            ironc.TabIndex = 33;
            ironc.Text = "label1";
            // 
            // coalc
            // 
            coalc.AutoSize = true;
            coalc.Font = new System.Drawing.Font("Consolas", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            coalc.Location = new System.Drawing.Point(554, 75);
            coalc.Name = "coalc";
            coalc.Size = new System.Drawing.Size(104, 32);
            coalc.TabIndex = 32;
            coalc.Text = "label1";
            // 
            // concreatc
            // 
            concreatc.AutoSize = true;
            concreatc.Font = new System.Drawing.Font("Consolas", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            concreatc.Location = new System.Drawing.Point(652, 75);
            concreatc.Name = "concreatc";
            concreatc.Size = new System.Drawing.Size(104, 32);
            concreatc.TabIndex = 31;
            concreatc.Text = "label1";
            // 
            // waterc
            // 
            waterc.AutoSize = true;
            waterc.Font = new System.Drawing.Font("Consolas", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            waterc.Location = new System.Drawing.Point(752, 75);
            waterc.Name = "waterc";
            waterc.Size = new System.Drawing.Size(104, 32);
            waterc.TabIndex = 30;
            waterc.Text = "label1";
            // 
            // Buy
            // 
            AutoScaleDimensions = new System.Drawing.SizeF(10F, 22F);
            AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            BackColor = System.Drawing.Color.Goldenrod;
            ClientSize = new System.Drawing.Size(856, 660);
            Controls.Add(ironc);
            Controls.Add(coalc);
            Controls.Add(concreatc);
            Controls.Add(waterc);
            Controls.Add(bt);
            Controls.Add(pictureBox1);
            Controls.Add(fff);
            Controls.Add(tooo);
            Controls.Add(you);
            Controls.Add(finalmoney);
            Controls.Add(totla);
            Controls.Add(yourmoneytext);
            Controls.Add(total);
            Controls.Add(label13);
            Controls.Add(watertotal);
            Controls.Add(cocreattotal);
            Controls.Add(coaltotal);
            Controls.Add(irontotal);
            Controls.Add(watermoney);
            Controls.Add(concreatmoney);
            Controls.Add(coalmoney);
            Controls.Add(ironmoney);
            Controls.Add(numericUpDownWater);
            Controls.Add(numericUpDownConcreat);
            Controls.Add(numericUpDownCoal);
            Controls.Add(numericUpDownIron);
            Controls.Add(water);
            Controls.Add(concreat);
            Controls.Add(coal);
            Controls.Add(iron);
            Controls.Add(finish);
            Controls.Add(buyyy);
            Controls.Add(sum);
            Controls.Add(clear);
            Font = new System.Drawing.Font("Consolas", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            ForeColor = System.Drawing.Color.Aqua;
            Margin = new System.Windows.Forms.Padding(4);
            Name = "Buy";
            Text = "Buy";
            Load += Buy_Load;
            ((System.ComponentModel.ISupportInitialize)numericUpDownIron).EndInit();
            ((System.ComponentModel.ISupportInitialize)numericUpDownCoal).EndInit();
            ((System.ComponentModel.ISupportInitialize)numericUpDownConcreat).EndInit();
            ((System.ComponentModel.ISupportInitialize)numericUpDownWater).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private System.Windows.Forms.Button clear;
        private System.Windows.Forms.Button sum;
        private System.Windows.Forms.Button buyyy;
        private System.Windows.Forms.Button finish;
        private System.Windows.Forms.Label iron;
        private System.Windows.Forms.Label coal;
        private System.Windows.Forms.Label concreat;
        private System.Windows.Forms.Label water;
        private System.Windows.Forms.NumericUpDown numericUpDownIron;
        private System.Windows.Forms.NumericUpDown numericUpDownCoal;
        private System.Windows.Forms.NumericUpDown numericUpDownConcreat;
        private System.Windows.Forms.NumericUpDown numericUpDownWater;
        private System.Windows.Forms.Label ironmoney;
        private System.Windows.Forms.Label coalmoney;
        private System.Windows.Forms.Label concreatmoney;
        private System.Windows.Forms.Label watermoney;
        private System.Windows.Forms.Label irontotal;
        private System.Windows.Forms.Label coaltotal;
        private System.Windows.Forms.Label cocreattotal;
        private System.Windows.Forms.Label watertotal;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label total;
        private System.Windows.Forms.Label yourmoneytext;
        private System.Windows.Forms.Label totla;
        private System.Windows.Forms.Label finalmoney;
        private System.Windows.Forms.Label you;
        private System.Windows.Forms.Label tooo;
        private System.Windows.Forms.Label fff;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label bt;
        private System.Windows.Forms.Label ironc;
        private System.Windows.Forms.Label coalc;
        private System.Windows.Forms.Label concreatc;
        private System.Windows.Forms.Label waterc;
    }
}