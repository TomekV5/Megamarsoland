﻿
namespace MX2
{
    partial class SmalPlot
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            a1 = new System.Windows.Forms.Button();
            money = new System.Windows.Forms.Label();
            b1 = new System.Windows.Forms.Button();
            c1 = new System.Windows.Forms.Button();
            a2 = new System.Windows.Forms.Button();
            b2 = new System.Windows.Forms.Button();
            c2 = new System.Windows.Forms.Button();
            a3 = new System.Windows.Forms.Button();
            b3 = new System.Windows.Forms.Button();
            c3 = new System.Windows.Forms.Button();
            menu = new System.Windows.Forms.ComboBox();
            comboBox1 = new System.Windows.Forms.ComboBox();
            comboBox2 = new System.Windows.Forms.ComboBox();
            comboBox3 = new System.Windows.Forms.ComboBox();
            comboBox4 = new System.Windows.Forms.ComboBox();
            comboBox5 = new System.Windows.Forms.ComboBox();
            comboBox6 = new System.Windows.Forms.ComboBox();
            comboBox7 = new System.Windows.Forms.ComboBox();
            comboBox8 = new System.Windows.Forms.ComboBox();
            buy = new System.Windows.Forms.Button();
            explore = new System.Windows.Forms.Button();
            waterc = new System.Windows.Forms.Label();
            concreatc = new System.Windows.Forms.Label();
            coalc = new System.Windows.Forms.Label();
            ironc = new System.Windows.Forms.Label();
            label7 = new System.Windows.Forms.Label();
            label6 = new System.Windows.Forms.Label();
            label5 = new System.Windows.Forms.Label();
            label4 = new System.Windows.Forms.Label();
            waterkon = new System.Windows.Forms.Label();
            concreatkon = new System.Windows.Forms.Label();
            coalkon = new System.Windows.Forms.Label();
            ironkon = new System.Windows.Forms.Label();
            comboBox9 = new System.Windows.Forms.ComboBox();
            chek = new System.Windows.Forms.Button();
            SuspendLayout();
            // 
            // a1
            // 
            a1.BackColor = System.Drawing.Color.MediumPurple;
            a1.Font = new System.Drawing.Font("Consolas", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            a1.ForeColor = System.Drawing.SystemColors.Desktop;
            a1.Location = new System.Drawing.Point(41, 54);
            a1.Name = "a1";
            a1.Size = new System.Drawing.Size(89, 35);
            a1.TabIndex = 0;
            a1.Text = "A1";
            a1.UseVisualStyleBackColor = false;
            a1.Click += a1_Click;
            // 
            // money
            // 
            money.AutoSize = true;
            money.Font = new System.Drawing.Font("Consolas", 14.25F, System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point);
            money.Location = new System.Drawing.Point(882, 19);
            money.Name = "money";
            money.Size = new System.Drawing.Size(70, 22);
            money.TabIndex = 1;
            money.Text = "label1";
            // 
            // b1
            // 
            b1.BackColor = System.Drawing.Color.MediumPurple;
            b1.Font = new System.Drawing.Font("Consolas", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            b1.ForeColor = System.Drawing.SystemColors.Desktop;
            b1.Location = new System.Drawing.Point(213, 54);
            b1.Name = "b1";
            b1.Size = new System.Drawing.Size(89, 35);
            b1.TabIndex = 2;
            b1.Text = "A1";
            b1.UseVisualStyleBackColor = false;
            b1.Click += b1_Click;
            // 
            // c1
            // 
            c1.BackColor = System.Drawing.Color.MediumPurple;
            c1.Font = new System.Drawing.Font("Consolas", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            c1.ForeColor = System.Drawing.SystemColors.Desktop;
            c1.Location = new System.Drawing.Point(383, 54);
            c1.Name = "c1";
            c1.Size = new System.Drawing.Size(89, 35);
            c1.TabIndex = 3;
            c1.Text = "A1";
            c1.UseVisualStyleBackColor = false;
            c1.Click += c1_Click;
            // 
            // a2
            // 
            a2.BackColor = System.Drawing.Color.MediumPurple;
            a2.Font = new System.Drawing.Font("Consolas", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            a2.ForeColor = System.Drawing.SystemColors.Desktop;
            a2.Location = new System.Drawing.Point(41, 139);
            a2.Name = "a2";
            a2.Size = new System.Drawing.Size(89, 35);
            a2.TabIndex = 4;
            a2.Text = "A1";
            a2.UseVisualStyleBackColor = false;
            a2.Click += a2_Click;
            // 
            // b2
            // 
            b2.BackColor = System.Drawing.Color.MediumPurple;
            b2.Font = new System.Drawing.Font("Consolas", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            b2.ForeColor = System.Drawing.SystemColors.Desktop;
            b2.Location = new System.Drawing.Point(213, 139);
            b2.Name = "b2";
            b2.Size = new System.Drawing.Size(89, 35);
            b2.TabIndex = 5;
            b2.Text = "A1";
            b2.UseVisualStyleBackColor = false;
            b2.Click += b2_Click;
            // 
            // c2
            // 
            c2.BackColor = System.Drawing.Color.MediumPurple;
            c2.Font = new System.Drawing.Font("Consolas", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            c2.ForeColor = System.Drawing.SystemColors.Desktop;
            c2.Location = new System.Drawing.Point(383, 139);
            c2.Name = "c2";
            c2.Size = new System.Drawing.Size(89, 35);
            c2.TabIndex = 6;
            c2.Text = "A1";
            c2.UseVisualStyleBackColor = false;
            c2.Click += c2_Click;
            // 
            // a3
            // 
            a3.BackColor = System.Drawing.Color.MediumPurple;
            a3.Font = new System.Drawing.Font("Consolas", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            a3.ForeColor = System.Drawing.SystemColors.Desktop;
            a3.Location = new System.Drawing.Point(41, 226);
            a3.Name = "a3";
            a3.Size = new System.Drawing.Size(89, 35);
            a3.TabIndex = 7;
            a3.Text = "A1";
            a3.UseVisualStyleBackColor = false;
            a3.Click += a3_Click;
            // 
            // b3
            // 
            b3.BackColor = System.Drawing.Color.MediumPurple;
            b3.Font = new System.Drawing.Font("Consolas", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            b3.ForeColor = System.Drawing.SystemColors.Desktop;
            b3.Location = new System.Drawing.Point(213, 226);
            b3.Name = "b3";
            b3.Size = new System.Drawing.Size(89, 35);
            b3.TabIndex = 8;
            b3.Text = "A1";
            b3.UseVisualStyleBackColor = false;
            b3.Click += b3_Click;
            // 
            // c3
            // 
            c3.BackColor = System.Drawing.Color.MediumPurple;
            c3.Font = new System.Drawing.Font("Consolas", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            c3.ForeColor = System.Drawing.SystemColors.Desktop;
            c3.Location = new System.Drawing.Point(383, 226);
            c3.Name = "c3";
            c3.Size = new System.Drawing.Size(89, 35);
            c3.TabIndex = 9;
            c3.Text = "A1";
            c3.UseVisualStyleBackColor = false;
            c3.Click += c3_Click;
            // 
            // menu
            // 
            menu.FormattingEnabled = true;
            menu.Items.AddRange(new object[] { "Rocket", "Solar Panel", "Batery", "Improve", "Storage" });
            menu.Location = new System.Drawing.Point(41, 86);
            menu.Name = "menu";
            menu.Size = new System.Drawing.Size(89, 30);
            menu.TabIndex = 10;
            // 
            // comboBox1
            // 
            comboBox1.FormattingEnabled = true;
            comboBox1.Items.AddRange(new object[] { "Rocket", "Solar Panel", "Batery", "Improve", "Storage" });
            comboBox1.Location = new System.Drawing.Point(213, 86);
            comboBox1.Name = "comboBox1";
            comboBox1.Size = new System.Drawing.Size(89, 30);
            comboBox1.TabIndex = 11;
            // 
            // comboBox2
            // 
            comboBox2.FormattingEnabled = true;
            comboBox2.Items.AddRange(new object[] { "Rocket", "Solar Panel", "Batery", "Improve", "Storage" });
            comboBox2.Location = new System.Drawing.Point(383, 86);
            comboBox2.Name = "comboBox2";
            comboBox2.Size = new System.Drawing.Size(89, 30);
            comboBox2.TabIndex = 12;
            // 
            // comboBox3
            // 
            comboBox3.FormattingEnabled = true;
            comboBox3.Items.AddRange(new object[] { "Rocket", "Solar Panel", "Batery", "Improve", "Storage" });
            comboBox3.Location = new System.Drawing.Point(41, 170);
            comboBox3.Name = "comboBox3";
            comboBox3.Size = new System.Drawing.Size(89, 30);
            comboBox3.TabIndex = 13;
            // 
            // comboBox4
            // 
            comboBox4.FormattingEnabled = true;
            comboBox4.Items.AddRange(new object[] { "Rocket", "Solar Panel", "Batery", "Improve", "Storage" });
            comboBox4.Location = new System.Drawing.Point(213, 170);
            comboBox4.Name = "comboBox4";
            comboBox4.Size = new System.Drawing.Size(89, 30);
            comboBox4.TabIndex = 14;
            // 
            // comboBox5
            // 
            comboBox5.FormattingEnabled = true;
            comboBox5.Items.AddRange(new object[] { "Rocket", "Solar Panel", "Batery", "Improve", "Storage" });
            comboBox5.Location = new System.Drawing.Point(383, 170);
            comboBox5.Name = "comboBox5";
            comboBox5.Size = new System.Drawing.Size(89, 30);
            comboBox5.TabIndex = 15;
            // 
            // comboBox6
            // 
            comboBox6.FormattingEnabled = true;
            comboBox6.Items.AddRange(new object[] { "Rocket", "Solar Panel", "Batery", "Improve", "Storage" });
            comboBox6.Location = new System.Drawing.Point(41, 256);
            comboBox6.Name = "comboBox6";
            comboBox6.Size = new System.Drawing.Size(89, 30);
            comboBox6.TabIndex = 16;
            // 
            // comboBox7
            // 
            comboBox7.FormattingEnabled = true;
            comboBox7.Items.AddRange(new object[] { "Rocket", "Solar Panel", "Batery", "Improve", "Storage" });
            comboBox7.Location = new System.Drawing.Point(213, 256);
            comboBox7.Name = "comboBox7";
            comboBox7.Size = new System.Drawing.Size(89, 30);
            comboBox7.TabIndex = 17;
            // 
            // comboBox8
            // 
            comboBox8.FormattingEnabled = true;
            comboBox8.Items.AddRange(new object[] { "Rocket", "Solar Panel", "Batery", "Improve", "Storage" });
            comboBox8.Location = new System.Drawing.Point(383, 256);
            comboBox8.Name = "comboBox8";
            comboBox8.Size = new System.Drawing.Size(89, 30);
            comboBox8.TabIndex = 18;
            // 
            // buy
            // 
            buy.BackColor = System.Drawing.Color.Yellow;
            buy.Font = new System.Drawing.Font("Consolas", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            buy.Location = new System.Drawing.Point(929, 170);
            buy.Name = "buy";
            buy.Size = new System.Drawing.Size(176, 52);
            buy.TabIndex = 19;
            buy.Text = "💰BUY💰";
            buy.UseVisualStyleBackColor = false;
            buy.Click += buy_Click;
            // 
            // explore
            // 
            explore.BackColor = System.Drawing.Color.Cyan;
            explore.Font = new System.Drawing.Font("Consolas", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            explore.Location = new System.Drawing.Point(929, 86);
            explore.Name = "explore";
            explore.Size = new System.Drawing.Size(176, 58);
            explore.TabIndex = 20;
            explore.Text = "🗺EXPLORE🗺";
            explore.UseVisualStyleBackColor = false;
            explore.Click += explore_Click;
            // 
            // waterc
            // 
            waterc.AutoSize = true;
            waterc.Font = new System.Drawing.Font("Consolas", 14.25F, System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point);
            waterc.Location = new System.Drawing.Point(779, 19);
            waterc.Name = "waterc";
            waterc.Size = new System.Drawing.Size(70, 22);
            waterc.TabIndex = 21;
            waterc.Text = "label1";
            // 
            // concreatc
            // 
            concreatc.AutoSize = true;
            concreatc.Font = new System.Drawing.Font("Consolas", 14.25F, System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point);
            concreatc.Location = new System.Drawing.Point(703, 19);
            concreatc.Name = "concreatc";
            concreatc.Size = new System.Drawing.Size(70, 22);
            concreatc.TabIndex = 22;
            concreatc.Text = "label1";
            // 
            // coalc
            // 
            coalc.AutoSize = true;
            coalc.Font = new System.Drawing.Font("Consolas", 14.25F, System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point);
            coalc.Location = new System.Drawing.Point(627, 19);
            coalc.Name = "coalc";
            coalc.Size = new System.Drawing.Size(70, 22);
            coalc.TabIndex = 23;
            coalc.Text = "label1";
            // 
            // ironc
            // 
            ironc.AutoSize = true;
            ironc.Font = new System.Drawing.Font("Consolas", 14.25F, System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point);
            ironc.Location = new System.Drawing.Point(551, 19);
            ironc.Name = "ironc";
            ironc.Size = new System.Drawing.Size(70, 22);
            ironc.TabIndex = 24;
            ironc.Text = "label1";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new System.Drawing.Font("Consolas", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            label7.Location = new System.Drawing.Point(872, 450);
            label7.Name = "label7";
            label7.Size = new System.Drawing.Size(90, 28);
            label7.TabIndex = 32;
            label7.Text = "Water:";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new System.Drawing.Font("Consolas", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            label6.Location = new System.Drawing.Point(872, 415);
            label6.Name = "label6";
            label6.Size = new System.Drawing.Size(129, 28);
            label6.TabIndex = 31;
            label6.Text = "Concreat:";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new System.Drawing.Font("Consolas", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            label5.Location = new System.Drawing.Point(872, 381);
            label5.Name = "label5";
            label5.Size = new System.Drawing.Size(77, 28);
            label5.TabIndex = 30;
            label5.Text = "Coal:";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new System.Drawing.Font("Consolas", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            label4.Location = new System.Drawing.Point(872, 347);
            label4.Name = "label4";
            label4.Size = new System.Drawing.Size(77, 28);
            label4.TabIndex = 29;
            label4.Text = "Iron:";
            // 
            // waterkon
            // 
            waterkon.AutoSize = true;
            waterkon.Font = new System.Drawing.Font("Consolas", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            waterkon.Location = new System.Drawing.Point(1011, 450);
            waterkon.Name = "waterkon";
            waterkon.Size = new System.Drawing.Size(25, 28);
            waterkon.TabIndex = 28;
            waterkon.Text = "0";
            // 
            // concreatkon
            // 
            concreatkon.AutoSize = true;
            concreatkon.Font = new System.Drawing.Font("Consolas", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            concreatkon.Location = new System.Drawing.Point(1011, 415);
            concreatkon.Name = "concreatkon";
            concreatkon.Size = new System.Drawing.Size(25, 28);
            concreatkon.TabIndex = 27;
            concreatkon.Text = "0";
            // 
            // coalkon
            // 
            coalkon.AutoSize = true;
            coalkon.Font = new System.Drawing.Font("Consolas", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            coalkon.Location = new System.Drawing.Point(1011, 381);
            coalkon.Name = "coalkon";
            coalkon.Size = new System.Drawing.Size(25, 28);
            coalkon.TabIndex = 26;
            coalkon.Text = "0";
            // 
            // ironkon
            // 
            ironkon.AutoSize = true;
            ironkon.Font = new System.Drawing.Font("Consolas", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            ironkon.Location = new System.Drawing.Point(1011, 347);
            ironkon.Name = "ironkon";
            ironkon.Size = new System.Drawing.Size(25, 28);
            ironkon.TabIndex = 25;
            ironkon.Text = "0";
            // 
            // comboBox9
            // 
            comboBox9.Font = new System.Drawing.Font("Consolas", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            comboBox9.FormattingEnabled = true;
            comboBox9.Items.AddRange(new object[] { "Rocket", "Solar Panel", "Batery", "Improve", "Storage" });
            comboBox9.Location = new System.Drawing.Point(919, 283);
            comboBox9.Name = "comboBox9";
            comboBox9.Size = new System.Drawing.Size(136, 36);
            comboBox9.TabIndex = 34;
            // 
            // chek
            // 
            chek.BackColor = System.Drawing.Color.Tomato;
            chek.Font = new System.Drawing.Font("Consolas", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            chek.Location = new System.Drawing.Point(919, 253);
            chek.Name = "chek";
            chek.Size = new System.Drawing.Size(136, 35);
            chek.TabIndex = 33;
            chek.Text = "CHECK";
            chek.UseVisualStyleBackColor = false;
            chek.Click += chek_Click;
            // 
            // SmalPlot
            // 
            AutoScaleDimensions = new System.Drawing.SizeF(10F, 22F);
            AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            BackColor = System.Drawing.Color.FromArgb(255, 128, 0);
            ClientSize = new System.Drawing.Size(1143, 660);
            Controls.Add(comboBox9);
            Controls.Add(chek);
            Controls.Add(label7);
            Controls.Add(label6);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(waterkon);
            Controls.Add(concreatkon);
            Controls.Add(coalkon);
            Controls.Add(ironkon);
            Controls.Add(ironc);
            Controls.Add(coalc);
            Controls.Add(concreatc);
            Controls.Add(waterc);
            Controls.Add(explore);
            Controls.Add(buy);
            Controls.Add(comboBox8);
            Controls.Add(comboBox7);
            Controls.Add(comboBox6);
            Controls.Add(comboBox5);
            Controls.Add(comboBox4);
            Controls.Add(comboBox3);
            Controls.Add(comboBox2);
            Controls.Add(comboBox1);
            Controls.Add(menu);
            Controls.Add(c3);
            Controls.Add(b3);
            Controls.Add(a3);
            Controls.Add(c2);
            Controls.Add(b2);
            Controls.Add(a2);
            Controls.Add(c1);
            Controls.Add(b1);
            Controls.Add(money);
            Controls.Add(a1);
            Font = new System.Drawing.Font("Consolas", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            ForeColor = System.Drawing.SystemColors.Desktop;
            Margin = new System.Windows.Forms.Padding(4);
            Name = "SmalPlot";
            Text = "SmalPlot";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private System.Windows.Forms.Button a1;
        private System.Windows.Forms.Label money;
        private System.Windows.Forms.Button b1;
        private System.Windows.Forms.Button c1;
        private System.Windows.Forms.Button a2;
        private System.Windows.Forms.Button b2;
        private System.Windows.Forms.Button c2;
        private System.Windows.Forms.Button a3;
        private System.Windows.Forms.Button b3;
        private System.Windows.Forms.Button c3;
        private System.Windows.Forms.ComboBox menu;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.ComboBox comboBox2;
        private System.Windows.Forms.ComboBox comboBox3;
        private System.Windows.Forms.ComboBox comboBox4;
        private System.Windows.Forms.ComboBox comboBox5;
        private System.Windows.Forms.ComboBox comboBox6;
        private System.Windows.Forms.ComboBox comboBox7;
        private System.Windows.Forms.ComboBox comboBox8;
        private System.Windows.Forms.Button buy;
        private System.Windows.Forms.Button explore;
        private System.Windows.Forms.Label waterc;
        private System.Windows.Forms.Label concreatc;
        private System.Windows.Forms.Label coalc;
        private System.Windows.Forms.Label ironc;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label waterkon;
        private System.Windows.Forms.Label concreatkon;
        private System.Windows.Forms.Label coalkon;
        private System.Windows.Forms.Label ironkon;
        private System.Windows.Forms.ComboBox comboBox9;
        private System.Windows.Forms.Button chek;
    }
}